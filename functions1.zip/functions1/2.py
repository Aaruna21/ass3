def solve():
    far = float(input())
    cel = (5/9)*(far-32)
    return cel
print(solve())