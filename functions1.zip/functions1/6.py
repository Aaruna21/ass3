def solve():
    s=input().split()
    print(" ".join(reversed(s)))
solve()