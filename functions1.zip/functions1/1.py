def solve():
    grams = float(input())
    un = grams * 28.3495231
    return un 
print(solve())
